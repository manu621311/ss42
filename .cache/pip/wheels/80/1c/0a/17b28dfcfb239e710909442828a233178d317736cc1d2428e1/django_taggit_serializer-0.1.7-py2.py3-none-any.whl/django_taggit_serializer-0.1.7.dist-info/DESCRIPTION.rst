The Django Taggit Serializer for the DjangoREST Framework developers. Installation can be found on https://github.com/glemmaPaul/django-taggit-serializer


